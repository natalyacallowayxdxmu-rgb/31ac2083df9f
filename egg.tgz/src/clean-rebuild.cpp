// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("clean rebuild\n", stdout);
  return lionss_run_workload("clean-rebuild");
}
