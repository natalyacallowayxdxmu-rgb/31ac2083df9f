// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("idempotency tests\n", stdout);
  return lionss_run_workload("idempotency-tests");
}
