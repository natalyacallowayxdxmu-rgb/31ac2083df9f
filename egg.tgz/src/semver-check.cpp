// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("semver check"); }
int main(){
  announce();
  return lionss_run_workload("semver-check");
}
