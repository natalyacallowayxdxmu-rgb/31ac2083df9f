// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("function coverage\n", stdout);
  return lionss_run_workload("function-coverage");
}
