# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(android-ndk-r26 src/android-ndk-r26.cpp)
set_property(TARGET android-ndk-r26 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-ndk-r26 lionss pthread)

add_executable(macos-arm64 src/macos-arm64.cpp)
set_property(TARGET macos-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-arm64 lionss pthread)

add_executable(coverage-diff src/coverage-diff.cpp)
set_property(TARGET coverage-diff PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-diff lionss pthread)

add_executable(idempotency-tests src/idempotency-tests.cpp)
set_property(TARGET idempotency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(idempotency-tests lionss pthread)

add_executable(build-pic src/build-pic.cpp)
set_property(TARGET build-pic PROPERTY CXX_STANDARD 11)
target_link_libraries(build-pic lionss pthread)

add_executable(semver-check src/semver-check.cpp)
set_property(TARGET semver-check PROPERTY CXX_STANDARD 11)
target_link_libraries(semver-check lionss pthread)

add_executable(clean-rebuild src/clean-rebuild.cpp)
set_property(TARGET clean-rebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(clean-rebuild lionss pthread)

add_executable(coroutines-check src/coroutines-check.cpp)
set_property(TARGET coroutines-check PROPERTY CXX_STANDARD 11)
target_link_libraries(coroutines-check lionss pthread)

add_executable(format-diff src/format-diff.cpp)
set_property(TARGET format-diff PROPERTY CXX_STANDARD 11)
target_link_libraries(format-diff lionss pthread)

add_executable(cache-bench src/cache-bench.cpp)
set_property(TARGET cache-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(cache-bench lionss pthread)

add_executable(man-pages src/man-pages.cpp)
set_property(TARGET man-pages PROPERTY CXX_STANDARD 11)
target_link_libraries(man-pages lionss pthread)

add_executable(wheel-build src/wheel-build.cpp)
set_property(TARGET wheel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wheel-build lionss pthread)

add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

add_executable(dependency-pin src/dependency-pin.cpp)
set_property(TARGET dependency-pin PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-pin lionss pthread)

add_executable(portage-ebuild src/portage-ebuild.cpp)
set_property(TARGET portage-ebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(portage-ebuild lionss pthread)

add_executable(function-coverage src/function-coverage.cpp)
set_property(TARGET function-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(function-coverage lionss pthread)

add_executable(cppcheck src/cppcheck.cpp)
set_property(TARGET cppcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(cppcheck lionss pthread)

add_executable(mkdocs-build src/mkdocs-build.cpp)
set_property(TARGET mkdocs-build PROPERTY CXX_STANDARD 11)
target_link_libraries(mkdocs-build lionss pthread)

add_executable(flake-detector src/flake-detector.cpp)
set_property(TARGET flake-detector PROPERTY CXX_STANDARD 11)
target_link_libraries(flake-detector lionss pthread)

add_executable(nightly src/nightly.cpp)
set_property(TARGET nightly PROPERTY CXX_STANDARD 11)
target_link_libraries(nightly lionss pthread)

add_executable(badge-check src/badge-check.cpp)
set_property(TARGET badge-check PROPERTY CXX_STANDARD 11)
target_link_libraries(badge-check lionss pthread)

add_executable(acceptance-tests src/acceptance-tests.cpp)
set_property(TARGET acceptance-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(acceptance-tests lionss pthread)

add_executable(haiku-build src/haiku-build.cpp)
set_property(TARGET haiku-build PROPERTY CXX_STANDARD 11)
target_link_libraries(haiku-build lionss pthread)

add_executable(perf-record src/perf-record.cpp)
set_property(TARGET perf-record PROPERTY CXX_STANDARD 11)
target_link_libraries(perf-record lionss pthread)

add_executable(api-tests src/api-tests.cpp)
set_property(TARGET api-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(api-tests lionss pthread)

add_executable(codechecker src/codechecker.cpp)
set_property(TARGET codechecker PROPERTY CXX_STANDARD 11)
target_link_libraries(codechecker lionss pthread)

add_executable(timezone-tests src/timezone-tests.cpp)
set_property(TARGET timezone-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timezone-tests lionss pthread)

add_executable(cross-mingw64 src/cross-mingw64.cpp)
set_property(TARGET cross-mingw64 PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-mingw64 lionss pthread)

add_executable(headless-tests src/headless-tests.cpp)
set_property(TARGET headless-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(headless-tests lionss pthread)

add_executable(upgrade-tests src/upgrade-tests.cpp)
set_property(TARGET upgrade-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(upgrade-tests lionss pthread)

